/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth } from './lib/firebase';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import EmployeeList from './components/EmployeeList';
import PayrollImporter from './components/PayrollImporter';
import CompanySettings from './components/CompanySettings';
import Statements from './components/Statements';
import Navbar from './components/Navbar';
import { LayoutDashboard, Users, FileUp, LogOut, Settings, FileText } from 'lucide-react';

import { ToastProvider } from './components/Toast';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!user) {
    return <Login />;
  }

  return (
    <ToastProvider>
      <Router>
        <div className="min-h-screen bg-slate-50 flex">
          {/* Sidebar */}
        <aside className="w-72 bg-white border-r border-slate-200 flex flex-col sticky top-0 h-screen">
          <div className="p-8 border-b border-slate-200 bg-slate-50/50">
            <h1 className="text-2xl font-black text-blue-600 flex items-center gap-3 tracking-tighter">
              <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-blue-200">
                F
              </div>
              FolhaBR
            </h1>
          </div>
          
          <nav className="flex-1 p-6 space-y-1.5">
            <div className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4 px-4">Menu Principal</div>
            <Navbar.Link to="/" icon={<LayoutDashboard size={22} />} label="Dashboard" />
            <Navbar.Link to="/employees" icon={<Users size={22} />} label="Funcionários" />
            <Navbar.Link to="/import" icon={<FileUp size={22} />} label="Importar Folha" />
            <Navbar.Link to="/statements" icon={<FileText size={22} />} label="Extratos" />
            
            <div className="pt-8 text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4 px-4">Configurações</div>
            <Navbar.Link to="/settings" icon={<Settings size={22} />} label="Minha Empresa" />
          </nav>

          <div className="p-6 border-t border-slate-200 bg-slate-50/30">
            <div className="flex items-center gap-3 mb-6 px-4">
              <div className="w-10 h-10 bg-slate-200 rounded-full flex items-center justify-center text-slate-500 overflow-hidden">
                {user.photoURL ? <img src={user.photoURL} alt="User" referrerPolicy="no-referrer" /> : <Users size={20} />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-bold text-slate-900 truncate">{user.displayName || 'Usuário'}</div>
                <div className="text-[10px] text-slate-500 truncate">{user.email}</div>
              </div>
            </div>
            <button 
              onClick={() => auth.signOut()}
              className="flex items-center gap-3 px-4 py-3 w-full text-slate-600 hover:bg-red-50 hover:text-red-600 rounded-xl transition-all font-medium group"
            >
              <LogOut size={20} className="group-hover:translate-x-0.5 transition-transform" />
              <span>Sair do Sistema</span>
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-auto">
          <div className="p-8 max-w-7xl mx-auto">
            <Routes>
              <Route path="/" element={<Dashboard />} />
              <Route path="/employees" element={<EmployeeList />} />
              <Route path="/import" element={<PayrollImporter />} />
              <Route path="/statements" element={<Statements />} />
              <Route path="/settings" element={<CompanySettings />} />
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </div>
        </main>
      </div>
    </Router>
    </ToastProvider>
  );
}

