import { TaxBracket } from '../types';

export const calculateINSS = (salary: number, brackets: TaxBracket[]): number => {
  let total = 0;
  let remaining = salary;

  // Progressive calculation
  for (const bracket of brackets) {
    const max = bracket.max || Infinity;
    const min = bracket.min;
    
    if (salary > min) {
      const taxableInThisBracket = Math.min(salary, max) - min;
      total += taxableInThisBracket * bracket.rate;
    }
  }
  
  // Cap at ceiling (last bracket max)
  const ceiling = brackets[brackets.length - 1].max || Infinity;
  if (salary > ceiling) {
    // Re-calculate based on ceiling if exceeded
    // Actually the progressive logic above handles it if we cap 'taxableInThisBracket'
  }

  return Number(total.toFixed(2));
};

export const calculateIRRF = (baseSalary: number, brackets: TaxBracket[]): number => {
  // Simple bracket lookup for IRRF (usually not progressive in the same way as INSS, 
  // but applied to the whole base minus deduction)
  for (const bracket of brackets) {
    const max = bracket.max || Infinity;
    if (baseSalary >= bracket.min && baseSalary <= max) {
      const tax = (baseSalary * bracket.rate) - bracket.deduction;
      return Math.max(0, Number(tax.toFixed(2)));
    }
  }
  return 0;
};

export const calculateFGTS = (salary: number): number => {
  return Number((salary * 0.08).toFixed(2));
};
