import React, { useEffect, useState } from 'react';
import { doc, getDoc, setDoc, collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { Company } from '../types';
import { Building2, Save, Loader2, CreditCard } from 'lucide-react';
import { motion } from 'motion/react';
import { useToast } from './Toast';

export default function CompanySettings() {
  const [company, setCompany] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { showToast } = useToast();
  const [formData, setFormData] = useState({
    name: '',
    cnpj: '',
    bankCode: '',
    bankAgency: '',
    bankAccount: '',
    pixKey: ''
  });

  useEffect(() => {
    const fetchCompany = async () => {
      if (!auth.currentUser) return;
      
      try {
        const q = query(collection(db, 'companies'), where('adminUid', '==', auth.currentUser.uid), limit(1));
        const snapshot = await getDocs(q);
        
        if (!snapshot.empty) {
          const data = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as Company;
          setCompany(data);
          setFormData({
            name: data.name || '',
            cnpj: data.cnpj || '',
            bankCode: data.bankCode || '',
            bankAgency: data.bankAgency || '',
            bankAccount: data.bankAccount || '',
            pixKey: data.pixKey || ''
          });
        } else {
          // No company found, we'll let the user create one
          setCompany(null);
          setLoading(false);
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'company_settings');
      } finally {
        setLoading(false);
      }
    };

    fetchCompany();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!auth.currentUser) return;
    setSaving(true);

    try {
      const id = company?.id || `company_${auth.currentUser.uid}`;
      await setDoc(doc(db, 'companies', id), {
        ...formData,
        adminUid: auth.currentUser.uid,
        updatedAt: new Date().toISOString()
      }, { merge: true });
      
      if (!company) {
        setCompany({ id, name: formData.name, cnpj: formData.cnpj, adminUid: auth.currentUser.uid });
      }
      
      showToast('Dados da empresa salvos com sucesso!', 'success');
    } catch (err: any) {
      handleFirestoreError(err, OperationType.WRITE, company ? `companies/${company.id}` : 'companies');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="animate-spin text-blue-600" size={32} />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-slate-900">
          {!company ? 'Cadastrar Minha Empresa' : 'Configurações da Empresa'}
        </h1>
        <p className="text-slate-500">
          {!company 
            ? 'Para começar a usar a FolhaBR, precisamos de alguns dados da sua empresa.' 
            : 'Gerencie os dados cadastrais e bancários da sua empresa.'}
        </p>
      </header>

      {!company && (
        <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100 flex items-start gap-4">
          <div className="p-3 bg-blue-600 rounded-xl text-white shadow-lg shadow-blue-200">
            <Building2 size={24} />
          </div>
          <div>
            <h3 className="font-bold text-blue-900">Primeiros Passos</h3>
            <p className="text-sm text-blue-700 mt-1">
              Cadastre sua empresa para habilitar a importação de funcionários e o processamento de folhas de pagamento.
            </p>
          </div>
        </div>
      )}

      <motion.form 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        onSubmit={handleSave} 
        className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden"
      >
        <div className="p-6 border-b border-slate-200 bg-slate-50/50 flex items-center gap-2">
          <Building2 size={20} className="text-blue-600" />
          <h2 className="font-bold text-slate-900">Dados Gerais</h2>
        </div>
        
        <div className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Razão Social</label>
              <input 
                type="text" 
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 outline-none"
                required
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">CNPJ</label>
              <input 
                type="text" 
                value={formData.cnpj}
                onChange={(e) => setFormData({ ...formData, cnpj: e.target.value })}
                className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 outline-none"
                placeholder="00.000.000/0001-00"
                required
              />
            </div>
          </div>
        </div>

        <div className="p-6 border-b border-t border-slate-200 bg-slate-50/50 flex items-center gap-2">
          <CreditCard size={20} className="text-blue-600" />
          <h2 className="font-bold text-slate-900">Dados Bancários (Conta da Empresa)</h2>
        </div>

        <div className="p-6 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Código Banco</label>
              <input 
                type="text" 
                value={formData.bankCode}
                onChange={(e) => setFormData({ ...formData, bankCode: e.target.value })}
                className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 outline-none"
                placeholder="Ex: 001, 341"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Agência</label>
              <input 
                type="text" 
                value={formData.bankAgency}
                onChange={(e) => setFormData({ ...formData, bankAgency: e.target.value })}
                className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 outline-none"
                placeholder="0001"
              />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-500 uppercase">Conta</label>
              <input 
                type="text" 
                value={formData.bankAccount}
                onChange={(e) => setFormData({ ...formData, bankAccount: e.target.value })}
                className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 outline-none"
                placeholder="12345-6"
              />
            </div>
          </div>
          <div className="space-y-1">
            <label className="text-xs font-bold text-slate-500 uppercase">Chave PIX</label>
            <input 
              type="text" 
              value={formData.pixKey}
              onChange={(e) => setFormData({ ...formData, pixKey: e.target.value })}
              className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 outline-none"
              placeholder="E-mail, CPF, CNPJ ou Celular"
            />
          </div>
        </div>

        <div className="p-6 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2 rounded-xl font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 shadow-sm"
          >
            {saving ? <Loader2 className="animate-spin" size={20} /> : <Save size={20} />}
            Salvar Alterações
          </button>
        </div>
      </motion.form>
    </div>
  );
}
