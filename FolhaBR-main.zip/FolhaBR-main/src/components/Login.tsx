import React, { useState } from 'react';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { auth } from '../lib/firebase';
import { LogIn } from 'lucide-react';

export default function Login() {
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      setError(err.message);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 p-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8 text-center">
        <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center text-white text-3xl font-bold mx-auto mb-6">
          F
        </div>
        <h1 className="text-2xl font-bold text-slate-900 mb-2">Bem-vindo ao FolhaBR</h1>
        <p className="text-slate-600 mb-8">Gestão de folha de pagamento CLT para empresas brasileiras.</p>
        
        {error && (
          <div className="bg-red-50 text-red-600 p-3 rounded-lg mb-6 text-sm">
            {error}
          </div>
        )}

        <button
          onClick={handleLogin}
          className="w-full flex items-center justify-center gap-3 bg-white border border-slate-200 text-slate-700 font-medium py-3 px-4 rounded-xl hover:bg-slate-50 transition-colors shadow-sm"
        >
          <LogIn size={20} />
          Entrar com Google
        </button>
        
        <p className="mt-8 text-xs text-slate-400">
          Ao entrar, você concorda com nossos termos de serviço e política de privacidade.
        </p>
      </div>
    </div>
  );
}
