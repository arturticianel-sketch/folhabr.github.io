import React, { useEffect, useState } from 'react';
import { collection, getDocs, query, limit, where, addDoc, doc, setDoc } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { Employee, Company } from '../types';
import { formatCurrency, formatCPF } from '../lib/utils';
import { Search, Plus, MoreVertical, User, Loader2, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useToast } from './Toast';

export default function EmployeeList() {
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [companyId, setCompanyId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const { showToast } = useToast();
  
  // Form state
  const [formData, setFormData] = useState({
    name: '',
    cpf: '',
    baseSalary: '',
    dependents: '0',
    bankCode: '',
    bankAgency: '',
    bankAccount: ''
  });

  const fetchEmployees = async () => {
    if (!auth.currentUser) return;
    setLoading(true);
    
    try {
      const companyQuery = query(
        collection(db, 'companies'), 
        where('adminUid', '==', auth.currentUser.uid), 
        limit(1)
      );
      const companySnap = await getDocs(companyQuery);
      
      if (!companySnap.empty) {
        const id = companySnap.docs[0].id;
        setCompanyId(id);
        const employeesPath = `companies/${id}/employees`;
        const snapshot = await getDocs(collection(db, employeesPath));
        const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Employee));
        setEmployees(data);
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, 'employees_list');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEmployees();
  }, []);

  const handleAddEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyId || !auth.currentUser) return;
    setSaving(true);

    try {
      const cpf = formData.cpf.replace(/\D/g, '');
      if (cpf.length !== 11) throw new Error('CPF deve ter 11 dígitos');

      const empData = {
        name: formData.name,
        cpf: cpf,
        baseSalary: parseFloat(formData.baseSalary),
        dependents: parseInt(formData.dependents),
        bankCode: formData.bankCode,
        bankAgency: formData.bankAgency,
        bankAccount: formData.bankAccount,
        companyId,
        updatedAt: new Date().toISOString()
      };

      const empRef = doc(db, `companies/${companyId}/employees`, cpf);
      await setDoc(empRef, empData, { merge: true });
      
      showToast('Funcionário adicionado com sucesso!', 'success');
      setShowModal(false);
      setFormData({
        name: '',
        cpf: '',
        baseSalary: '',
        dependents: '0',
        bankCode: '',
        bankAgency: '',
        bankAccount: ''
      });
      fetchEmployees();
    } catch (error: any) {
      showToast('Erro ao salvar: ' + error.message, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Funcionários</h1>
          <p className="text-slate-500">Gerencie o cadastro de colaboradores da sua empresa.</p>
        </div>
        <button 
          onClick={() => setShowModal(true)}
          className="flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-xl font-medium hover:bg-blue-700 transition-colors shadow-sm"
        >
          <Plus size={20} />
          Novo Funcionário
        </button>
      </header>

      {/* Modal */}
      <AnimatePresence>
        {showModal && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-xl w-full max-w-lg overflow-hidden"
            >
              <div className="p-6 border-b border-slate-200 flex justify-between items-center">
                <h2 className="text-xl font-bold text-slate-900">Adicionar Funcionário</h2>
                <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                  <X size={24} />
                </button>
              </div>
              
              <form onSubmit={handleAddEmployee} className="p-6 space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-1">Nome Completo</label>
                    <input 
                      required
                      type="text" 
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                      className="w-full p-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 outline-none"
                      placeholder="Ex: João Silva"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">CPF</label>
                    <input 
                      required
                      type="text" 
                      value={formData.cpf}
                      onChange={e => setFormData({...formData, cpf: e.target.value})}
                      className="w-full p-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 outline-none"
                      placeholder="000.000.000-00"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Salário Base</label>
                    <input 
                      required
                      type="number" 
                      step="0.01"
                      value={formData.baseSalary}
                      onChange={e => setFormData({...formData, baseSalary: e.target.value})}
                      className="w-full p-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 outline-none"
                      placeholder="R$ 0,00"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Dependentes</label>
                    <input 
                      type="number" 
                      value={formData.dependents}
                      onChange={e => setFormData({...formData, dependents: e.target.value})}
                      className="w-full p-2.5 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 outline-none"
                    />
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100">
                  <h3 className="text-sm font-bold text-slate-900 mb-3">Dados Bancários</h3>
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-xs font-medium text-slate-500 mb-1">Banco (Cód)</label>
                      <input 
                        type="text" 
                        value={formData.bankCode}
                        onChange={e => setFormData({...formData, bankCode: e.target.value})}
                        className="w-full p-2 border border-slate-200 rounded-lg text-sm"
                        placeholder="341"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-500 mb-1">Agência</label>
                      <input 
                        type="text" 
                        value={formData.bankAgency}
                        onChange={e => setFormData({...formData, bankAgency: e.target.value})}
                        className="w-full p-2 border border-slate-200 rounded-lg text-sm"
                        placeholder="0001"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-slate-500 mb-1">Conta</label>
                      <input 
                        type="text" 
                        value={formData.bankAccount}
                        onChange={e => setFormData({...formData, bankAccount: e.target.value})}
                        className="w-full p-2 border border-slate-200 rounded-lg text-sm"
                        placeholder="12345-6"
                      />
                    </div>
                  </div>
                </div>

                <div className="pt-6 flex gap-3">
                  <button 
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="flex-1 px-4 py-2.5 border border-slate-200 text-slate-600 rounded-xl font-medium hover:bg-slate-50 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button 
                    type="submit"
                    disabled={saving}
                    className="flex-1 px-4 py-2.5 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {saving ? <Loader2 className="animate-spin" size={20} /> : <Plus size={20} />}
                    {saving ? 'Salvando...' : 'Adicionar'}
                  </button>
                </div>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 bg-slate-50/50 flex items-center gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input 
              type="text" 
              placeholder="Buscar por nome ou CPF..."
              className="w-full pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4">Colaborador</th>
                <th className="px-6 py-4">CPF</th>
                <th className="px-6 py-4">Salário Base</th>
                <th className="px-6 py-4">Dependentes</th>
                <th className="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center">
                    <Loader2 className="animate-spin mx-auto text-blue-600" size={32} />
                  </td>
                </tr>
              ) : employees.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                    Nenhum funcionário cadastrado.
                  </td>
                </tr>
              ) : (
                employees.map((emp) => (
                  <tr key={emp.id} className="hover:bg-slate-50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 group-hover:bg-blue-50 group-hover:text-blue-500 transition-colors">
                          <User size={20} />
                        </div>
                        <span className="font-medium text-slate-900">{emp.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-slate-600">{formatCPF(emp.cpf)}</td>
                    <td className="px-6 py-4 text-slate-600">{formatCurrency(emp.baseSalary)}</td>
                    <td className="px-6 py-4 text-slate-600">{emp.dependents}</td>
                    <td className="px-6 py-4 text-right">
                      <button className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-all">
                        <MoreVertical size={18} />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
