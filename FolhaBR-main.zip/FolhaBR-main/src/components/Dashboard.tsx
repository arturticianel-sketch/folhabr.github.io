import React, { useEffect, useState } from 'react';
import { collection, query, where, getDocs, setDoc, doc, limit, orderBy } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { PayrollBatch, TaxTable, Company } from '../types';
import { formatCurrency } from '../lib/utils';
import { TrendingUp, Users, FileText, AlertCircle, CheckCircle2, Clock, Loader2, CreditCard, X, ShieldCheck, Receipt } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useToast } from './Toast';

export default function Dashboard() {
  const [batches, setBatches] = useState<PayrollBatch[]>([]);
  const [loading, setLoading] = useState(true);
  const [seeding, setSeeding] = useState(false);
  const [company, setCompany] = useState<Company | null>(null);
  const [selectedBatch, setSelectedBatch] = useState<PayrollBatch | null>(null);
  const [paying, setPaying] = useState(false);
  const [showAllBatches, setShowAllBatches] = useState(false);
  const { showToast } = useToast();

  useEffect(() => {
    const fetchData = async () => {
      if (!auth.currentUser) return;
      
      try {
        // 1. Find user's company
        const companyQuery = query(
          collection(db, 'companies'), 
          where('adminUid', '==', auth.currentUser.uid), 
          limit(1)
        );
        const companySnap = await getDocs(companyQuery);
        
        if (!companySnap.empty) {
          const companyData = { id: companySnap.docs[0].id, ...companySnap.docs[0].data() } as Company;
          setCompany(companyData);

          // 2. Fetch batches for this company
          const batchesPath = `companies/${companyData.id}/payroll_batches`;
          const q = query(
            collection(db, batchesPath), 
            limit(50)
          );
          const snapshot = await getDocs(q);
          const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as PayrollBatch));
          setBatches(data.sort((a, b) => b.createdAt.localeCompare(a.createdAt)));
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'dashboard_data');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const seedTaxTables = async () => {
    setSeeding(true);
    try {
      const inssTable: TaxTable = {
        id: 'inss_2024',
        type: 'INSS',
        year: 2024,
        brackets: [
          { min: 0, max: 1412.00, rate: 0.075, deduction: 0 },
          { min: 1412.01, max: 2666.68, rate: 0.09, deduction: 21.18 },
          { min: 2666.69, max: 4000.03, rate: 0.12, deduction: 101.18 },
          { min: 4000.04, max: 7786.02, rate: 0.14, deduction: 181.18 }
        ]
      };

      const irrfTable: TaxTable = {
        id: 'irrf_2024',
        type: 'IRRF',
        year: 2024,
        brackets: [
          { min: 0, max: 2112.00, rate: 0, deduction: 0 },
          { min: 2112.01, max: 2826.65, rate: 0.075, deduction: 158.40 },
          { min: 2826.66, max: 3751.05, rate: 0.15, deduction: 370.40 },
          { min: 3751.06, max: 4664.68, rate: 0.225, deduction: 651.73 },
          { min: 4664.69, max: null, rate: 0.275, deduction: 884.96 }
        ]
      };

      await setDoc(doc(db, 'tax_tables', inssTable.id), inssTable);
      await setDoc(doc(db, 'tax_tables', irrfTable.id), irrfTable);
      showToast('Tabelas de impostos inicializadas com sucesso!', 'success');
    } catch (err: any) {
      showToast('Erro ao inicializar tabelas: ' + err.message, 'error');
    } finally {
      setSeeding(false);
    }
  };

  const executePayment = async () => {
    if (!company || !selectedBatch) return;
    setPaying(true);

    try {
      const batchRef = doc(db, `companies/${company.id}/payroll_batches`, selectedBatch.id);
      await setDoc(batchRef, { 
        status: 'paid', 
        paidAt: new Date().toISOString(),
        paymentMethod: 'PIX/Transferência',
        executedBy: auth.currentUser?.email
      }, { merge: true });
      
      setBatches(batches.map(b => b.id === selectedBatch.id ? { ...b, status: 'paid' } : b));
      setSelectedBatch(null);
      showToast('Pagamento executado com sucesso!', 'success');
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `payroll_batches/${selectedBatch.id}`);
    } finally {
      setPaying(false);
    }
  };

  const handleDownloadReceipt = (batch: PayrollBatch) => {
    const content = `
COMPROVANTE DE PAGAMENTO DE FOLHA - FolhaBR
-------------------------------------------
Empresa: ${company?.name}
CNPJ: ${company?.cnpj}
Competência: ${batch.month}
Data do Pagamento: ${new Date(batch.paidAt || batch.createdAt).toLocaleString('pt-BR')}
-------------------------------------------
Total Bruto: ${formatCurrency(batch.totalGross)}
Total Impostos: ${formatCurrency(batch.totalTaxes)}
Total Líquido Pago: ${formatCurrency(batch.totalNet)}
-------------------------------------------
Status: PAGO
Autenticação: ${batch.id.toUpperCase()}
    `;
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `comprovante_${batch.month.replace('/', '_')}.txt`;
    link.click();
    showToast('Comprovante gerado com sucesso!', 'success');
  };

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Dashboard Financeiro</h1>
          <p className="text-slate-500">Visão geral da folha de pagamento e impostos.</p>
        </div>
        <button 
          onClick={seedTaxTables}
          disabled={seeding}
          className="text-xs text-slate-400 hover:text-slate-600 transition-colors"
        >
          {seeding ? 'Inicializando...' : 'Inicializar Tabelas de Impostos'}
        </button>
      </header>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard 
          title="Total Folha (Mês)" 
          value={formatCurrency(batches.reduce((acc, b) => acc + b.totalGross, 0))} 
          icon={<TrendingUp className="text-blue-600" />}
          trend="+5.2% vs mês anterior"
        />
        <StatCard 
          title="Total Impostos" 
          value={formatCurrency(batches.reduce((acc, b) => acc + b.totalTaxes, 0))} 
          icon={<AlertCircle className="text-amber-600" />}
          trend="FGTS, INSS, IRRF"
        />
        <StatCard 
          title="Colaboradores" 
          value="42" 
          icon={<Users className="text-emerald-600" />}
          trend="Ativos na plataforma"
        />
      </div>

      {/* Recent Batches */}
      <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm">
        <div className="p-6 border-b border-slate-200 flex justify-between items-center">
          <h2 className="text-lg font-bold text-slate-900">Folhas Recentes</h2>
          {batches.length > 5 && (
            <button 
              onClick={() => setShowAllBatches(!showAllBatches)}
              className="text-blue-600 text-sm font-medium hover:underline"
            >
              {showAllBatches ? 'Ver menos' : 'Ver todas'}
            </button>
          )}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4">Competência</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Total Bruto</th>
                <th className="px-6 py-4">Total Líquido</th>
                <th className="px-6 py-4">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {batches.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-slate-400">
                    Nenhuma folha processada ainda.
                  </td>
                </tr>
              ) : (
                (showAllBatches ? batches : batches.slice(0, 5)).map((batch) => (
                  <tr key={batch.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4 font-medium text-slate-900">{batch.month}</td>
                    <td className="px-6 py-4">
                      <StatusBadge status={batch.status} />
                    </td>
                    <td className="px-6 py-4 text-slate-600">{formatCurrency(batch.totalGross)}</td>
                    <td className="px-6 py-4 text-slate-600">{formatCurrency(batch.totalNet)}</td>
                    <td className="px-6 py-4">
                      {batch.status !== 'paid' && (
                        <button 
                          onClick={() => setSelectedBatch(batch)}
                          className="text-xs bg-emerald-600 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-emerald-700 transition-colors shadow-sm flex items-center gap-1"
                        >
                          <CreditCard size={14} />
                          Pagar
                        </button>
                      )}
                      {batch.status === 'paid' && (
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-emerald-600 font-bold flex items-center gap-1">
                            <CheckCircle2 size={14} />
                            Pago
                          </span>
                          <button 
                            onClick={() => handleDownloadReceipt(batch)}
                            className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                            title="Gerar Comprovante"
                          >
                            <Receipt size={16} />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Payment Modal */}
      <AnimatePresence>
        {selectedBatch && (
          <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden"
            >
              <div className="p-6 border-b border-slate-200 flex justify-between items-center bg-slate-50">
                <div className="flex items-center gap-2">
                  <CreditCard className="text-blue-600" size={24} />
                  <h2 className="text-xl font-bold text-slate-900">Executar Pagamento</h2>
                </div>
                <button onClick={() => setSelectedBatch(null)} className="text-slate-400 hover:text-slate-600">
                  <X size={24} />
                </button>
              </div>

              <div className="p-6 space-y-6">
                <div className="bg-blue-50 p-4 rounded-xl border border-blue-100">
                  <div className="text-sm text-blue-600 font-medium mb-1">Total a Pagar (Líquido)</div>
                  <div className="text-3xl font-bold text-blue-900">{formatCurrency(selectedBatch.totalNet)}</div>
                  <div className="text-xs text-blue-400 mt-1">Competência: {selectedBatch.month}</div>
                </div>

                <div className="space-y-4">
                  <div>
                    <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Origem (Sua Empresa)</h3>
                    <div className="p-3 bg-slate-50 rounded-lg border border-slate-100">
                      <div className="text-sm font-bold text-slate-900">{company?.name}</div>
                      <div className="text-xs text-slate-500">CNPJ: {company?.cnpj}</div>
                      <div className="text-xs text-slate-500 mt-1">
                        Banco: {company?.bankCode} | Ag: {company?.bankAgency} | CC: {company?.bankAccount}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-emerald-600 bg-emerald-50 p-3 rounded-lg border border-emerald-100">
                    <ShieldCheck size={20} />
                    <span className="text-xs font-medium">Pagamento seguro via FolhaBR Gateway</span>
                  </div>
                </div>

                <div className="pt-4 flex gap-3">
                  <button 
                    onClick={() => setSelectedBatch(null)}
                    className="flex-1 px-4 py-3 border border-slate-200 text-slate-600 rounded-xl font-medium hover:bg-slate-50 transition-colors"
                  >
                    Cancelar
                  </button>
                  <button 
                    onClick={executePayment}
                    disabled={paying}
                    className="flex-1 px-4 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-200 disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {paying ? <Loader2 className="animate-spin" size={20} /> : <CheckCircle2 size={20} />}
                    {paying ? 'Processando...' : 'Confirmar'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function StatCard({ title, value, icon, trend }: { title: string; value: string; icon: React.ReactNode; trend: string }) {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm"
    >
      <div className="flex justify-between items-start mb-4">
        <div className="p-3 bg-slate-50 rounded-xl">
          {icon}
        </div>
      </div>
      <h3 className="text-slate-500 text-sm font-medium mb-1">{title}</h3>
      <div className="text-2xl font-bold text-slate-900 mb-2">{value}</div>
      <div className="text-xs text-slate-400">{trend}</div>
    </motion.div>
  );
}

function StatusBadge({ status }: { status: string }) {
  const styles = {
    draft: "bg-slate-100 text-slate-600",
    calculated: "bg-blue-100 text-blue-600",
    paid: "bg-emerald-100 text-emerald-600"
  };
  
  const icons = {
    draft: <Clock size={14} />,
    calculated: <FileText size={14} />,
    paid: <CheckCircle2 size={14} />
  };

  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${styles[status as keyof typeof styles]}`}>
      {icons[status as keyof typeof icons]}
      {status.charAt(0).toUpperCase() + status.slice(1)}
    </span>
  );
}
