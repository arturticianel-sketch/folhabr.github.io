import React from 'react';
import { NavLink } from 'react-router-dom';
import { cn } from '../lib/utils';

const Navbar = {
  Link: ({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) => (
    <NavLink
      to={to}
      className={({ isActive }) =>
        cn(
          "flex items-center gap-3 px-4 py-2 rounded-lg transition-colors",
          isActive 
            ? "bg-blue-50 text-blue-600 font-medium" 
            : "text-slate-600 hover:bg-slate-50"
        )
      }
    >
      {icon}
      <span>{label}</span>
    </NavLink>
  )
};

export default Navbar;
