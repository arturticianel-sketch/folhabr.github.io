import { useState, useEffect, useMemo } from 'react';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { PayrollEntry, PayrollBatch, Company } from '../types';
import { formatCurrency, formatCPF } from '../lib/utils';
import { Search, Filter, Loader2, FileText, Download, Receipt } from 'lucide-react';
import { motion } from 'motion/react';
import { useToast } from './Toast';

interface ExtendedPayrollEntry extends PayrollEntry {
  month: string;
  batchStatus: string;
  paidAt?: string;
}

export default function Statements() {
  const [entries, setEntries] = useState<ExtendedPayrollEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [company, setCompany] = useState<Company | null>(null);
  const { showToast } = useToast();

  // Filters
  const [searchTerm, setSearchTerm] = useState('');
  const [monthFilter, setMonthFilter] = useState('');
  const [minSalary, setMinSalary] = useState('');
  const [maxSalary, setMaxSalary] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      if (!auth.currentUser) return;
      
      try {
        // 1. Find user's company
        const companyQuery = query(
          collection(db, 'companies'), 
          where('adminUid', '==', auth.currentUser.uid), 
          limit(1)
        );
        const companySnap = await getDocs(companyQuery);
        
        if (!companySnap.empty) {
          const companyData = { id: companySnap.docs[0].id, ...companySnap.docs[0].data() } as Company;
          setCompany(companyData);

          // 2. Fetch all batches to get their IDs and months
          const batchesPath = `companies/${companyData.id}/payroll_batches`;
          const batchesSnap = await getDocs(collection(db, batchesPath));
          
          const allEntries: ExtendedPayrollEntry[] = [];

          // 3. Fetch entries for each batch
          for (const batchDoc of batchesSnap.docs) {
            const batchData = batchDoc.data() as PayrollBatch;
            const entriesPath = `${batchesPath}/${batchDoc.id}/entries`;
            const entriesSnap = await getDocs(collection(db, entriesPath));
            
            entriesSnap.forEach(entryDoc => {
              allEntries.push({
                ...(entryDoc.data() as PayrollEntry),
                id: entryDoc.id,
                month: batchData.month,
                batchStatus: batchData.status,
                paidAt: batchData.paidAt
              });
            });
          }

          // Sort by month descending, then by employee name
          allEntries.sort((a, b) => {
            if (a.month !== b.month) return b.month.localeCompare(a.month);
            return a.employeeName.localeCompare(b.employeeName);
          });

          setEntries(allEntries);
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, 'statements_data');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const filteredEntries = useMemo(() => {
    const normalizedSearch = searchTerm.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
    const searchNumbers = searchTerm.replace(/\D/g, '');

    return entries.filter(entry => {
      let matchesSearch = true;
      if (searchTerm.trim() !== '') {
        const entryName = (entry.employeeName || '').toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
        const matchesName = entryName.includes(normalizedSearch);
        const matchesCPF = searchNumbers.length > 0 ? (entry.employeeId || '').includes(searchNumbers) : false;
        matchesSearch = matchesName || matchesCPF;
      }

      const matchesMonth = monthFilter ? entry.month === monthFilter : true;
      
      const min = minSalary !== '' ? parseFloat(minSalary) : 0;
      const max = maxSalary !== '' ? parseFloat(maxSalary) : Infinity;
      
      const finalMin = isNaN(min) ? 0 : min;
      const finalMax = isNaN(max) ? Infinity : max;
      
      const matchesSalary = entry.netSalary >= finalMin && entry.netSalary <= finalMax;

      return matchesSearch && matchesMonth && matchesSalary;
    });
  }, [entries, searchTerm, monthFilter, minSalary, maxSalary]);

  const uniqueMonths = useMemo(() => {
    const months = new Set(entries.map(e => e.month));
    return Array.from(months).sort((a, b) => b.localeCompare(a));
  }, [entries]);

  const handleDownloadReceipt = (entry: ExtendedPayrollEntry) => {
    const content = `
HOLERITE / EXTRATO DE PAGAMENTO - FolhaBR
-------------------------------------------
Empresa: ${company?.name}
CNPJ: ${company?.cnpj}
Competência: ${entry.month}
Data do Pagamento: ${entry.paidAt ? new Date(entry.paidAt).toLocaleString('pt-BR') : 'Pendente'}
-------------------------------------------
Funcionário: ${entry.employeeName}
CPF: ${formatCPF(entry.employeeId)}
-------------------------------------------
VENCIMENTOS
Salário Bruto: ${formatCurrency(entry.grossSalary)}

DESCONTOS
INSS: ${formatCurrency(entry.inss)}
IRRF: ${formatCurrency(entry.irrf)}

FGTS (Não descontado): ${formatCurrency(entry.fgts)}
-------------------------------------------
LÍQUIDO A RECEBER: ${formatCurrency(entry.netSalary)}
-------------------------------------------
Status da Folha: ${entry.batchStatus === 'paid' ? 'PAGO' : 'PENDENTE'}
Autenticação: ${entry.id.toUpperCase()}
    `;
    
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `holerite_${entry.employeeName.replace(/\s+/g, '_')}_${entry.month.replace('/', '_')}.txt`;
    link.click();
    showToast('Holerite gerado com sucesso!', 'success');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <Loader2 className="animate-spin text-blue-600" size={32} />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-black text-slate-900 tracking-tight">Extratos e Holerites</h1>
        <p className="text-slate-500 mt-2">Consulte o histórico detalhado de pagamentos por funcionário.</p>
      </header>

      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
        {/* Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input
              type="text"
              placeholder="Buscar por nome ou CPF..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
            />
          </div>
          
          <div>
            <select
              value={monthFilter}
              onChange={(e) => setMonthFilter(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
            >
              <option value="">Todas as competências</option>
              {uniqueMonths.map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>

          <div>
            <input
              type="number"
              placeholder="Salário Líquido Mínimo"
              value={minSalary}
              onChange={(e) => setMinSalary(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
            />
          </div>

          <div>
            <input
              type="number"
              placeholder="Salário Líquido Máximo"
              value={maxSalary}
              onChange={(e) => setMaxSalary(e.target.value)}
              className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-600 focus:border-transparent outline-none transition-all"
            />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto rounded-xl border border-slate-200">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4">Competência</th>
                <th className="px-6 py-4">Funcionário</th>
                <th className="px-6 py-4">Salário Bruto</th>
                <th className="px-6 py-4">Descontos</th>
                <th className="px-6 py-4">Líquido</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredEntries.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-slate-400">
                    <FileText size={48} className="mx-auto mb-4 text-slate-300" />
                    Nenhum extrato encontrado com os filtros atuais.
                  </td>
                </tr>
              ) : (
                filteredEntries.map((entry) => (
                  <motion.tr 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    key={entry.id} 
                    className="hover:bg-slate-50 transition-colors"
                  >
                    <td className="px-6 py-4 font-medium text-slate-900">{entry.month}</td>
                    <td className="px-6 py-4">
                      <div className="font-medium text-slate-900">{entry.employeeName}</div>
                      <div className="text-xs text-slate-500">{formatCPF(entry.employeeId)}</div>
                    </td>
                    <td className="px-6 py-4 text-slate-600">{formatCurrency(entry.grossSalary)}</td>
                    <td className="px-6 py-4 text-red-600">
                      -{formatCurrency(entry.inss + entry.irrf)}
                    </td>
                    <td className="px-6 py-4 font-bold text-emerald-600">{formatCurrency(entry.netSalary)}</td>
                    <td className="px-6 py-4">
                      {entry.batchStatus === 'paid' ? (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-emerald-100 text-emerald-800">
                          Pago
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800">
                          Pendente
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => handleDownloadReceipt(entry)}
                        className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all inline-flex items-center gap-2"
                        title="Baixar Holerite"
                      >
                        <Download size={18} />
                      </button>
                    </td>
                  </motion.tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
