import React, { useState, useCallback } from 'react';
import { useDropzone, DropzoneOptions } from 'react-dropzone';
import { collection, addDoc, getDocs, query, where, doc, setDoc, limit } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { PayrollBatch, PayrollEntry, TaxTable, Company } from '../types';
import { calculateINSS, calculateIRRF, calculateFGTS } from '../services/payrollEngine';
import { formatCurrency, formatCPF } from '../lib/utils';
import { FileUp, AlertCircle, CheckCircle2, Loader2, Download } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useToast } from './Toast';

export default function PayrollImporter() {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [preview, setPreview] = useState<PayrollEntry[]>([]);
  const [month, setMonth] = useState(new Date().toISOString().slice(0, 7)); // YYYY-MM
  const { showToast } = useToast();

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFile(acceptedFiles[0]);
    setError(null);
    setPreview([]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'text/csv': ['.csv'] },
    multiple: false
  } as any);

  const handleProcess = async () => {
    if (!file) return;
    setUploading(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch('/api/payroll/parse-csv', {
        method: 'POST',
        body: formData
      });

      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('text/html')) {
        throw new Error('Erro de conexão com o servidor (Resposta HTML inesperada). O servidor pode estar reiniciando.');
      }

      if (!response.ok) {
        const text = await response.text();
        let errorMessage = 'Erro ao processar arquivo';
        try {
          const data = JSON.parse(text);
          errorMessage = data.error || errorMessage;
        } catch {
          errorMessage = `Erro do servidor (${response.status}): ${text.slice(0, 100)}`;
        }
        throw new Error(errorMessage);
      }

      const { employees } = await response.json();
      
      // Fetch tax tables - Filter in memory to avoid index requirements
      try {
        const taxTablesSnap = await getDocs(collection(db, 'tax_tables'));
        const allTables = taxTablesSnap.docs.map(d => d.data() as TaxTable);
        
        const inssTable = allTables.find(t => t.type === 'INSS' && t.year === 2024);
        const irrfTable = allTables.find(t => t.type === 'IRRF' && t.year === 2024);
        
        if (!inssTable || !irrfTable) {
          throw new Error('Tabelas de impostos de 2024 não encontradas. Inicialize-as no Dashboard.');
        }

        // Calculate payroll for each employee
        const calculatedEntries: PayrollEntry[] = employees.map((emp: any) => {
          const inss = calculateINSS(emp.baseSalary, inssTable.brackets);
          const baseIrrf = emp.baseSalary - inss - (emp.dependents * 189.59);
          const irrf = calculateIRRF(baseIrrf, irrfTable.brackets);
          const fgts = calculateFGTS(emp.baseSalary);
          const net = emp.baseSalary - inss - irrf;

          return {
            id: Math.random().toString(36).substr(2, 9),
            batchId: 'temp',
            employeeId: emp.cpf, // Using CPF as temp ID
            employeeName: emp.name,
            grossSalary: emp.baseSalary,
            inss,
            irrf,
            fgts,
            netSalary: net
          };
        });

        setPreview(calculatedEntries);
      } catch (err: any) {
        handleFirestoreError(err, OperationType.LIST, 'tax_tables');
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  const handleSave = async () => {
    if (preview.length === 0 || !auth.currentUser) return;
    setUploading(true);

    try {
      // 1. Find user's company
      const companyQuery = query(
        collection(db, 'companies'), 
        where('adminUid', '==', auth.currentUser.uid), 
        limit(1)
      );
      const companySnap = await getDocs(companyQuery);
      
      if (companySnap.empty) {
        throw new Error('Empresa não cadastrada. Por favor, cadastre sua empresa nas Configurações antes de salvar a folha.');
      }

      const companyId = companySnap.docs[0].id;
      const totalGross = preview.reduce((acc, e) => acc + e.grossSalary, 0);
      const totalNet = preview.reduce((acc, e) => acc + e.netSalary, 0);
      const totalTaxes = preview.reduce((acc, e) => acc + e.inss + e.irrf + e.fgts, 0);

      const batch: Omit<PayrollBatch, 'id'> = {
        companyId,
        month,
        status: 'calculated',
        totalGross,
        totalNet,
        totalTaxes,
        createdAt: new Date().toISOString()
      };

      const batchesPath = `companies/${companyId}/payroll_batches`;
      const batchRef = await addDoc(collection(db, batchesPath), batch);
      
      // Save entries and update employees
      for (const entry of preview) {
        const entriesPath = `${batchesPath}/${batchRef.id}/entries`;
        await addDoc(collection(db, entriesPath), {
          ...entry,
          batchId: batchRef.id
        });
        
        // Update/Create employee record in the correct subcollection
        const empPath = `companies/${companyId}/employees`;
        const empRef = doc(db, empPath, entry.employeeId);
        await setDoc(empRef, {
          name: entry.employeeName,
          cpf: entry.employeeId,
          baseSalary: entry.grossSalary,
          companyId,
          updatedAt: new Date().toISOString()
        }, { merge: true });
      }

      showToast('Folha de pagamento e dados dos funcionários salvos com sucesso!', 'success');
      setPreview([]);
      setFile(null);
    } catch (err: any) {
      setError('Erro ao salvar: ' + err.message);
      handleFirestoreError(err, OperationType.WRITE, 'payroll_save');
    } finally {
      setUploading(false);
    }
  };

  const handleDownloadTemplate = () => {
    const headers = ['name', 'cpf', 'salary', 'dependents', 'bankCode', 'bankAgency', 'bankAccount'];
    const sampleData = [
      ['João Silva', '12345678909', '5000.00', '1', '341', '1234', '12345-6'],
      ['Maria Oliveira', '98765432100', '4200.50', '0', '001', '4321', '54321-0']
    ];
    
    const csvContent = [
      headers.join(','),
      ...sampleData.map(row => row.join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', 'modelo_folha_br.csv');
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-slate-900">Importar Folha</h1>
        <p className="text-slate-500">Envie o arquivo CSV com os dados dos colaboradores para cálculo automático.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Upload Section */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
            <label className="block text-sm font-medium text-slate-700">Mês de Competência</label>
            <input 
              type="month" 
              value={month}
              onChange={(e) => setMonth(e.target.value)}
              className="w-full p-2 border border-slate-200 rounded-lg focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 outline-none"
            />
            
            <div 
              {...getRootProps()} 
              className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all cursor-pointer ${
                isDragActive ? 'border-blue-500 bg-blue-50' : 'border-slate-200 hover:border-slate-300'
              }`}
            >
              <input {...getInputProps()} />
              <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center mx-auto mb-4 text-slate-400">
                <FileUp size={24} />
              </div>
              <p className="text-sm text-slate-600">
                {file ? file.name : 'Arraste o CSV ou clique para selecionar'}
              </p>
              <p className="text-xs text-slate-400 mt-2">Apenas arquivos .csv</p>
            </div>

            {error && (
              <div className="flex items-start gap-2 p-3 bg-red-50 text-red-600 rounded-lg text-sm">
                <AlertCircle size={16} className="shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <button
              onClick={handleProcess}
              disabled={!file || uploading}
              className="w-full flex items-center justify-center gap-2 bg-blue-600 text-white py-3 rounded-xl font-medium hover:bg-blue-700 transition-colors disabled:opacity-50 shadow-sm"
            >
              {uploading ? <Loader2 className="animate-spin" size={20} /> : <CheckCircle2 size={20} />}
              {uploading ? 'Processando...' : 'Calcular Folha'}
            </button>
          </div>

          <div className="bg-blue-50 p-6 rounded-2xl border border-blue-100">
            <h3 className="text-blue-800 font-bold mb-2 flex items-center gap-2">
              <Download size={18} />
              Modelo de Arquivo
            </h3>
            <p className="text-blue-600 text-sm mb-4">Certifique-se de que seu CSV tenha as colunas: name, cpf, salary, dependents.</p>
            <button 
              onClick={handleDownloadTemplate}
              className="text-blue-700 text-sm font-bold hover:underline flex items-center gap-1"
            >
              <Download size={14} />
              Baixar CSV Exemplo
            </button>
          </div>
        </div>

        {/* Preview Section */}
        <div className="lg:col-span-2">
          <AnimatePresence mode="wait">
            {preview.length > 0 ? (
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden"
              >
                <div className="p-6 border-b border-slate-200 flex justify-between items-center bg-slate-50/50">
                  <div>
                    <h2 className="text-lg font-bold text-slate-900">Prévia do Cálculo</h2>
                    <p className="text-sm text-slate-500">{preview.length} colaboradores identificados.</p>
                  </div>
                  <button 
                    onClick={handleSave}
                    className="bg-emerald-600 text-white px-6 py-2 rounded-xl font-medium hover:bg-emerald-700 transition-colors shadow-sm"
                  >
                    Salvar e Finalizar
                  </button>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider text-[10px] font-bold">
                      <tr>
                        <th className="px-6 py-4">Nome</th>
                        <th className="px-6 py-4">Bruto</th>
                        <th className="px-6 py-4">INSS</th>
                        <th className="px-6 py-4">IRRF</th>
                        <th className="px-6 py-4">FGTS</th>
                        <th className="px-6 py-4">Líquido</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {preview.map((entry) => (
                        <tr key={entry.id} className="hover:bg-slate-50 transition-colors">
                          <td className="px-6 py-4">
                            <div className="font-medium text-slate-900">{entry.employeeName}</div>
                            <div className="text-[10px] text-slate-400">{formatCPF(entry.employeeId)}</div>
                          </td>
                          <td className="px-6 py-4 text-slate-600">{formatCurrency(entry.grossSalary)}</td>
                          <td className="px-6 py-4 text-red-500">-{formatCurrency(entry.inss)}</td>
                          <td className="px-6 py-4 text-red-500">-{formatCurrency(entry.irrf)}</td>
                          <td className="px-6 py-4 text-slate-400">{formatCurrency(entry.fgts)}</td>
                          <td className="px-6 py-4 font-bold text-emerald-600">{formatCurrency(entry.netSalary)}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-slate-50 font-bold text-slate-900">
                      <tr>
                        <td className="px-6 py-4">TOTAL</td>
                        <td className="px-6 py-4">{formatCurrency(preview.reduce((acc, e) => acc + e.grossSalary, 0))}</td>
                        <td colSpan={3}></td>
                        <td className="px-6 py-4 text-emerald-600">{formatCurrency(preview.reduce((acc, e) => acc + e.netSalary, 0))}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </motion.div>
            ) : (
              <div className="h-full min-h-[400px] flex flex-col items-center justify-center bg-slate-50 border-2 border-dashed border-slate-200 rounded-2xl text-slate-400">
                <FileUp size={48} className="mb-4 opacity-20" />
                <p>Aguardando upload de arquivo para exibir prévia.</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}
