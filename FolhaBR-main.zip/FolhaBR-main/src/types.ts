export interface Company {
  id: string;
  name: string;
  cnpj: string;
  adminUid: string;
  bankCode?: string;
  bankAgency?: string;
  bankAccount?: string;
  pixKey?: string;
}

export interface Employee {
  id: string;
  companyId: string;
  name: string;
  cpf: string;
  baseSalary: number;
  dependents: number;
  bankCode?: string;
  bankAgency?: string;
  bankAccount?: string;
}

export interface PayrollBatch {
  id: string;
  companyId: string;
  month: string;
  status: 'draft' | 'calculated' | 'paid';
  totalGross: number;
  totalNet: number;
  totalTaxes: number;
  createdAt: string;
  paidAt?: string;
  paymentId?: string;
}

export interface PayrollEntry {
  id: string;
  batchId: string;
  employeeId: string;
  employeeName: string;
  grossSalary: number;
  inss: number;
  irrf: number;
  fgts: number;
  netSalary: number;
}

export interface TaxBracket {
  min: number;
  max: number | null;
  rate: number;
  deduction: number;
}

export interface TaxTable {
  id: string;
  type: 'INSS' | 'IRRF';
  year: number;
  brackets: TaxBracket[];
}
